// ==========================================================================
// CORE APP DATA STATE MATRIX (Default Core Content Blueprint)
// ==========================================================================
const DEFAULT_SERVICES = [
    { id: "s1", name: "Website Development", desc: "We create clean, modern, responsive websites for businesses and personal brands.", icon: "fa-solid fa-code" },
    { id: "s2", name: "Mobile App Development", desc: "We build mobile-friendly digital solutions that help businesses serve customers better.", icon: "fa-solid fa-mobile-screen-button" },
    { id: "s3", name: "Landing Pages", desc: "We design powerful landing pages for adverts, campaigns, products, and services.", icon: "fa-solid fa-rocket" },
    { id: "s4", name: "Business Branding", desc: "We help businesses create a strong visual identity that customers can trust.", icon: "fa-solid fa-signature" },
    { id: "s5", name: "Digital Advert Designs", desc: "We create premium posters, flyers, banners, and social media adverts.", icon: "fa-solid fa-palette" },
    { id: "s6", name: "Social Media Promotion", desc: "We help brands become visible online with creative digital content.", icon: "fa-solid fa-bullhorn" },
    { id: "s7", name: "Creative Business Solutions", desc: "We provide smart ideas and digital tools to help businesses grow.", icon: "fa-solid fa-lightbulb" }
];

const DEFAULT_PROJECTS = [
    { id: "p1", title: "Business Website Design", desc: "Premium custom corporate visibility pipeline built for scalability.", img: "" },
    { id: "p2", title: "Premium Advertisement Poster", desc: "High conversion structural asset built for immediate social reach.", img: "" },
    { id: "p3", title: "Landing Page Campaign", desc: "Frictionless UI capture page optimizing lead conversions.", img: "" },
    { id: "p4", title: "Mobile-Friendly Brand Page", desc: "Fluid custom responsive layout targeted at mobile demographics.", img: "" }
];

// App initialization runtime layout state loading
let servicesData = JSON.parse(localStorage.getItem("lex_services")) || [...DEFAULT_SERVICES];
let projectsData = JSON.parse(localStorage.getItem("lex_projects")) || [...DEFAULT_PROJECTS];
let uploadedImageMap = JSON.parse(localStorage.getItem("lex_images")) || {};

// ==========================================================================
// INITIALIZATION DOM LOAD ROOT TRIGGER
// ==========================================================================
document.addEventListener("DOMContentLoaded", () => {
    initMobileMenu();
    loadHeroText();
    renderServices();
    renderProjects();
    initControlForms();
    initContactForm();
    setupLiveTextListeners();
});

// ==========================================================================
// MOBILE MENU NAVIGATION SYSTEM
// ==========================================================================
function initMobileMenu() {
    const hamburgerBtn = document.getElementById("hamburgerBtn");
    const navLinks = document.getElementById("navLinks");
    
    hamburgerBtn.addEventListener("click", () => {
        navLinks.classList.toggle("active");
        const icon = hamburgerBtn.querySelector("i");
        if(navLinks.classList.contains("active")) {
            icon.className = "fa-solid fa-xmark";
        } else {
            icon.className = "fa-solid fa-bars";
        }
    });

    // Close options menu cleanly on individual page jumping
    document.querySelectorAll(".nav-links a").forEach(link => {
        link.addEventListener("click", () => {
            navLinks.classList.remove("active");
            hamburgerBtn.querySelector("i").className = "fa-solid fa-bars";
        });
    });
}

// ==========================================================================
// RENDER & DOM INJECTION MODULES
// ==========================================================================

// Load text nodes for Hero presentation
function loadHeroText() {
    const savedTitle = localStorage.getItem("lex_hero_title");
    const savedSub = localStorage.getItem("lex_hero_sub");
    
    if(savedTitle) document.getElementById("heroHeadline").innerText = savedTitle;
    if(savedSub) document.getElementById("heroSubheadline").innerText = savedSub;
    
    // Auto populate control form placeholders with current visual values
    document.getElementById("inputHeroTitle").value = document.getElementById("heroHeadline").innerText;
    document.getElementById("inputHeroSub").value = document.getElementById("heroSubheadline").innerText;
}

// Map Array elements out live onto service HTML viewport
function renderServices() {
    const container = document.getElementById("servicesContainer");
    container.innerHTML = ""; // Clear visual stack prior to render pass
    
    servicesData.forEach(srv => {
        const card = document.createElement("div");
        card.className = "glass-card service-card";
        card.innerHTML = `
            <div class="service-icon-box">
                <i class="${srv.icon}"></i>
            </div>
            <h3 contenteditable="true" class="srv-inline-title" data-id="${srv.id}">${srv.name}</h3>
            <p contenteditable="true" class="srv-inline-desc" data-id="${srv.id}">${srv.desc}</p>
            <div class="item-actions">
                <button class="btn btn-small btn-secondary text-danger" onclick="deleteService('${srv.id}')">
                    <i class="fa-solid fa-trash-can"></i> Remove
                </button>
            </div>
        `;
        container.appendChild(card);
    });
}

// Map Array elements out live onto dynamic project block layout
function renderProjects() {
    const container = document.getElementById("projectsContainer");
    container.innerHTML = "";
    
    projectsData.forEach(proj => {
        const card = document.createElement("div");
        card.className = "glass-card project-card";
        
        // Handle custom binary images or fall back onto structural background design
        const displayImg = uploadedImageMap[proj.id] ? 
            `<img src="${uploadedImageMap[proj.id]}" alt="Project Cover">` : 
            `<i class="fa-solid fa-laptop-code"></i>`;

        card.innerHTML = `
            <div class="project-img-placeholder">
                ${displayImg}
            </div>
            <div class="project-body">
                <h4 contenteditable="true" class="proj-inline-title" data-id="${proj.id}">${proj.title}</h4>
                <p contenteditable="true" class="proj-inline-desc" data-id="${proj.id}">${proj.desc}</p>
                <div class="item-actions">
                    <a href="#contact" class="btn btn-small btn-primary">View Project</a>
                    <button class="btn btn-small btn-secondary text-danger" onclick="deleteProject('${proj.id}')">
                        <i class="fa-solid fa-trash-can"></i> Delete
                    </button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

// ==========================================================================
// CONTROL INTERFACES & REACTION SCHEMES
// ==========================================================================
function initControlForms() {
    // Hero Text Management Button event hook
    document.getElementById("btnUpdateHero").addEventListener("click", () => {
        const titleVal = document.getElementById("inputHeroTitle").value.trim();
        const subVal = document.getElementById("inputHeroSub").value.trim();
        
        if(titleVal) document.getElementById("heroHeadline").innerText = titleVal;
        if(subVal) document.getElementById("heroSubheadline").innerText = subVal;
        
        localStorage.setItem("lex_hero_title", titleVal);
        localStorage.setItem("lex_hero_sub", subVal);
        alert("Hero layout changed successfully!");
    });

    // Add Service Entry Event Module
    document.getElementById("btnAddService").addEventListener("click", () => {
        const title = document.getElementById("srvTitle").value.trim();
        const desc = document.getElementById("srvDesc").value.trim();
        const icon = document.getElementById("srvIcon").value.trim();

        if(!title || !desc) {
            alert("Please input both a title and service details description.");
            return;
        }

        const newService = {
            id: "s_" + Date.now(),
            name: title,
            desc: desc,
            icon: icon || "fa-solid fa-cubes"
        };

        servicesData.push(newService);
        renderServices();
        
        // Clear input form spaces cleanly
        document.getElementById("srvTitle").value = "";
        document.getElementById("srvDesc").value = "";
    });

    // Add Project Showcase Card Event Module
    const fileInput = document.getElementById("projImgFile");
    document.getElementById("btnAddProject").addEventListener("click", () => {
        const title = document.getElementById("projTitle").value.trim();
        const desc = document.getElementById("projDesc").value.trim();

        if(!title || !desc) {
            alert("Please fill in basic project titles and descriptions.");
            return;
        }

        const projectId = "p_" + Date.now();
        const newProject = { id: projectId, title: title, desc: desc };

        // Process asset attachment inside memory block cleanly
        if(fileInput.files && fileInput.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                uploadedImageMap[projectId] = e.target.result;
                projectsData.push(newProject);
                renderProjects();
                saveCurrentLayoutState();
            };
            reader.readAsDataURL(fileInput.files[0]);
        } else {
            projectsData.push(newProject);
            renderProjects();
        }

        // Reset text boxes cleanly
        document.getElementById("projTitle").value = "";
        document.getElementById("projDesc").value = "";
        fileInput.value = "";
    });

    // General persistent commit state lock
    document.getElementById("btnSaveStorage").addEventListener("click", () => {
        saveCurrentLayoutState();
        alert("Success! All configurations have been locked securely inside the browser Storage matrix.");
    });

    // Factory Hard Wipe Event Hook execution routing
    document.getElementById("btnResetStorage").addEventListener("click", () => {
        if(confirm("Are you absolutely sure you want to clear your updates and restore the system default design?")) {
            localStorage.clear();
            location.reload();
        }
    });
}

// ==========================================================================
// INLINE EDIT DETECTION HOOK PIPELINES
// ==========================================================================
function setupLiveTextListeners() {
    // Dynamic event listening on dynamic text updates
    document.addEventListener("input", (e) => {
        if(e.target.classList.contains("srv-inline-title")) {
            const id = e.target.getAttribute("data-id");
            const targetSrv = servicesData.find(s => s.id === id);
            if(targetSrv) targetSrv.name = e.target.innerText;
        }
        if(e.target.classList.contains("srv-inline-desc")) {
            const id = e.target.getAttribute("data-id");
            const targetSrv = servicesData.find(s => s.id === id);
            if(targetSrv) targetSrv.desc = e.target.innerText;
        }
        if(e.target.classList.contains("proj-inline-title")) {
            const id = e.target.getAttribute("data-id");
            const targetProj = projectsData.find(p => p.id === id);
            if(targetProj) targetProj.title = e.target.innerText;
        }
        if(e.target.classList.contains("proj-inline-desc")) {
            const id = e.target.getAttribute("data-id");
            const targetProj = projectsData.find(p => p.id === id);
            if(targetProj) targetProj.desc = e.target.innerText;
        }
    });
}

// Remove item triggers mapping array
window.deleteService = function(id) {
    servicesData = servicesData.filter(s => s.id !== id);
    renderServices();
};

window.deleteProject = function(id) {
    projectsData = projectsData.filter(p => p.id !== id);
    if(uploadedImageMap[id]) delete uploadedImageMap[id];
    renderProjects();
};

// Global Serialization sync execution call
function saveCurrentLayoutState() {
    localStorage.setItem("lex_services", JSON.stringify(servicesData));
    localStorage.setItem("lex_projects", JSON.stringify(projectsData));
    localStorage.setItem("lex_images", JSON.stringify(uploadedImageMap));
}

// ==========================================================================
// CONTACT INPUT PIPELINE VALIDATION MODULE
// ==========================================================================
function initContactForm() {
    const form = document.getElementById("contactForm");
    const feedback = document.getElementById("formFeedback");

    form.addEventListener("submit", (e) => {
        e.preventDefault(); // Hold native submit call
        
        const name = document.getElementById("frmName").value.trim();
        const email = document.getElementById("frmEmail").value.trim();
        const phone = document.getElementById("frmPhone").value.trim();
        const msg = document.getElementById("frmMessage").value.trim();

        if(!name || !email || !phone || !msg) {
            feedback.style.color = "#ff4d4d";
            feedback.innerText = "Please complete all active entry lines securely.";
            return;
        }

        feedback.style.color = "#00f2fe";
        feedback.innerText = "Validation Approved! Forwarding data stream over WhatsApp connect...";
        
        // Assemble target deep link string for dynamic handoff
        const baseMessage = `Hello Lexamitch Enterprises, my name is ${name}. ${msg}. Contact me at ${phone} or email: ${email}`;
        const encodedUrl = "https://wa.me/2348029287090?text=" + encodeURIComponent(baseMessage);
        
        // Push target launch after standard operational confirmation delay
        setTimeout(() => {
            window.open(encodedUrl, "_blank");
            form.reset();
            feedback.innerText = "";
        }, 1200);
    });
}